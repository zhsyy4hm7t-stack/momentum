// Trimite e-mailuri (Resend) la cerere nouă și la schimbarea statusului/datei.
// Apelată de Database Webhooks (INSERT + UPDATE pe public.bookings).
// Secrete (doar în Supabase, niciodată în frontend): WEBHOOK_SECRET, RESEND_API_KEY, FROM_EMAIL, STAFF_EMAIL
const ST: Record<string, string> = { pending: "În așteptare", confirmed: "Confirmată", completed: "Finalizată", cancelled: "Anulată" };
const esc = (s: unknown) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
const dRO = (d: string) => new Date(d + "T12:00:00").toLocaleDateString("ro-RO", { day: "2-digit", month: "long", year: "numeric" });

async function send(to: string, subject: string, html: string) {
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${Deno.env.get("RESEND_API_KEY")}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: Deno.env.get("FROM_EMAIL"), to, subject, html }),
  });
  if (!r.ok) throw new Error(`Resend ${r.status}: ${await r.text()}`);
}

Deno.serve(async (req) => {
  if (req.headers.get("x-webhook-secret") !== Deno.env.get("WEBHOOK_SECRET")) return new Response("forbidden", { status: 403 });
  const { type, record: b, old_record: o } = await req.json();
  if (!b) return new Response("ok");
  const summary = `<p><b>Referință:</b> ${esc(b.ref)}<br><b>Serviciu:</b> ${esc(b.service_name)}<br><b>Data:</b> ${dRO(b.booking_date)}, ${esc(b.slot_label)}<br><b>Cimitir:</b> ${esc(b.cemetery)}, ${esc(b.city)}</p>`;
  try {
    if (type === "INSERT") {
      await send(b.email, `MONUMENTUM – Am primit cererea ${b.ref}`,
        `<p>Bună ziua, ${esc(b.customer_name)},</p><p>Am primit cererea dumneavoastră. Vă vom confirma în curând.</p>${summary}<p>Păstrați referința pentru a verifica statusul pe site.</p>`);
      const staff = Deno.env.get("STAFF_EMAIL");
      if (staff) await send(staff, `Cerere nouă ${b.ref}`, `<p>Cerere nouă de la ${esc(b.customer_name)}, tel. ${esc(b.phone)}.</p>${summary}<p>Deschideți panoul de administrare pentru detalii.</p>`);
    } else if (type === "UPDATE" && o && (o.status !== b.status || o.booking_date !== b.booking_date || o.slot_label !== b.slot_label)) {
      await send(b.email, `MONUMENTUM – Cererea ${b.ref}: ${ST[b.status] ?? b.status}`,
        `<p>Bună ziua, ${esc(b.customer_name)},</p><p>Statusul cererii dumneavoastră este acum: <b>${esc(ST[b.status] ?? b.status)}</b>.</p>${summary}`);
    }
  } catch (e) { console.error(e); return new Response("email_error", { status: 500 }); }
  return new Response("ok");
});
