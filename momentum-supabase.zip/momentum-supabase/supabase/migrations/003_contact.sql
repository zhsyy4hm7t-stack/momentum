-- Actualizează doar telefonul și e-mailul afișate pe site. Nu șterge nimic.
update public.settings set phone = '0722347849', email = 'monumentum.servicii@gmail.com' where id = 1;
