-- MONUMENTUM – migrare opțională 002. Rulați în SQL Editor DOAR după ce ați citit explicațiile.
-- NU șterge nicio rezervare, NU modifică prețurile, NU atinge tabelele bookings/staff/settings/time_slots.

-- PASUL A: actualizează doar textele serviciilor (nume, descriere, durată). Prețurile rămân neschimbate.
update public.services set name='Curățare de bază', duration='45–60 min',
  description='Spălarea monumentului și a crucii, îndepărtarea frunzelor și a impurităților. Potrivită pentru întreținerea periodică a mormântului.' where id='s1';
update public.services set name='Curățare profundă a monumentului', duration='2–3 ore',
  description='Curățare amănunțită a lespezii, crucii și soclului, cu produse și metode alese în funcție de tipul de piatră.' where id='s2';
update public.services set name='Îndepărtare mușchi, licheni și buruieni', duration='1–2 ore',
  description='Eliminarea mușchiului, lichenilor și a vegetației nedorite, cu atenție la suprafața pietrei.' where id='s3';
update public.services set name='Îngrijirea zonei din jurul mormântului', duration='1–2 ore',
  description='Curățarea și aranjarea spațiului din jur: borduri, alei mici și zona verde.' where id='s4';
update public.services set name='Flori și întreținere sezonieră', duration='30–60 min',
  description='Aranjamente florale proaspete, plantare și pregătirea mormântului pentru sărbători și pomeniri. Prețul variază în funcție de aranjamentul ales.' where id='s5';
update public.services set name='Pachet personalizat', duration='Variabil',
  description='Combinăm serviciile după nevoile dumneavoastră. Prețul se stabilește după discuție.' where id='s6';

-- PASUL B: serverul forțează orașul „București” pentru orice cerere nouă (chiar dacă cineva ocolește formularul).
-- Se înlocuiește doar funcția create_booking; rezervările existente nu se modifică.
create or replace function public.create_booking(p jsonb) returns text
language plpgsql security definer set search_path = public as $$
declare v_svc public.services; v_cap int; v_date date; v_slot text; v_phone text; v_ref text;
begin
  if coalesce(p->>'hp','') <> '' then raise exception 'invalid_request'; end if;
  v_date := (p->>'date')::date; v_slot := p->>'slot'; v_phone := trim(p->>'phone');
  if v_date is null or v_date < (now() at time zone 'Europe/Bucharest')::date then raise exception 'invalid_date'; end if;
  select * into v_svc from public.services where id = p->>'service_id' and active;
  if not found then raise exception 'invalid_service'; end if;
  select capacity into v_cap from public.time_slots where label = v_slot;
  if v_cap is null then raise exception 'invalid_slot'; end if;
  perform pg_advisory_xact_lock(hashtext(v_date::text || '|' || v_slot));
  if (select count(*) from public.bookings where booking_date = v_date and slot_label = v_slot
        and status in ('pending','confirmed')) >= v_cap then raise exception 'slot_taken'; end if;
  if (select count(*) from public.bookings where phone = v_phone and created_at > now() - interval '24 hours') >= 5
    then raise exception 'rate_limit'; end if;
  v_ref := 'MOM-' || upper(encode(gen_random_bytes(4), 'hex'));
  insert into public.bookings (ref, service_id, service_name, cemetery, city, section, plot, row_no, grave_no,
      booking_date, slot_label, customer_name, phone, email, notes)
  values (v_ref, v_svc.id, v_svc.name, trim(p->>'cemetery'), 'București', trim(p->>'section'),
      nullif(trim(p->>'plot'),''), nullif(trim(p->>'row'),''), nullif(trim(p->>'grave'),''),
      v_date, v_slot, trim(p->>'name'), v_phone, lower(trim(p->>'email')), nullif(trim(p->>'notes'),''));
  return v_ref;
end $$;
