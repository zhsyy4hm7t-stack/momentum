-- MONUMENTUM – schema Supabase. Rulați în SQL Editor (o singură dată).
create extension if not exists pgcrypto;

create table public.settings (
  id int primary key default 1 check (id = 1),
  phone text not null default '', email text not null default '',
  hours text not null default 'Luni–Vineri, 09:00–17:00');
insert into public.settings default values;

create table public.services (
  id text primary key, name text not null, description text, duration text,
  price numeric not null default 0, sort int not null default 0, active boolean not null default true);

create table public.time_slots (
  id serial primary key, label text not null unique,
  capacity int not null default 1 check (capacity > 0), sort int not null default 0);

create table public.staff (user_id uuid primary key references auth.users on delete cascade, email text);

create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  ref text not null unique,
  service_id text references public.services(id) on update cascade,
  service_name text not null,
  cemetery text not null check (char_length(cemetery) between 2 and 150),
  city text not null check (char_length(city) between 2 and 100),
  section text not null check (char_length(section) between 1 and 100),
  plot text check (char_length(plot) <= 50),
  row_no text check (char_length(row_no) <= 50),
  grave_no text check (char_length(grave_no) <= 50),
  booking_date date not null,
  slot_label text not null,
  customer_name text not null check (char_length(customer_name) between 2 and 120),
  phone text not null check (char_length(phone) between 6 and 30),
  email text not null check (char_length(email) <= 200 and email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  notes text check (char_length(notes) <= 1000),
  internal_notes text check (char_length(internal_notes) <= 2000),
  status text not null default 'pending' check (status in ('pending','confirmed','completed','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now());
create index on public.bookings (booking_date, slot_label) where status in ('pending','confirmed');
create index on public.bookings (phone, created_at);

-- Date de pornire (prețuri ilustrative, editabile din panoul admin)
insert into public.services (id,name,description,duration,price,sort) values
('s1','Curățare de bază','Spălarea monumentului, îndepărtarea frunzelor și a impurităților de pe suprafața mormântului.','45–60 min',150,1),
('s2','Curățare profundă a pietrei funerare','Curățare detaliată a lespezii și a crucii, cu produse adecvate tipului de piatră.','2–3 ore',350,2),
('s3','Îndepărtare mușchi, mizerie și buruieni','Eliminarea mușchiului, lichenilor și a vegetației nedorite, fără a deteriora piatra.','1–2 ore',250,3),
('s4','Curățarea și întreținerea zonei din jur','Îngrijirea spațiului din jurul mormântului: borduri, alei, spațiu verde.','1–2 ore',200,4),
('s5','Aranjamente florale și întreținere sezonieră','Flori proaspete sau aranjamente de sezon, plantare și întreținere.','30–60 min',180,5),
('s6','Pachet personalizat','Combinăm serviciile după nevoile dumneavoastră. Prețul se stabilește după discuție.','Variabil',0,6);
insert into public.time_slots (label,sort) values ('09:00–11:00',1),('11:00–13:00',2),('14:00–16:00',3);

-- ========== Securitate: RLS ==========
alter table public.settings enable row level security;
alter table public.services enable row level security;
alter table public.time_slots enable row level security;
alter table public.staff enable row level security;
alter table public.bookings enable row level security;

create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = public as
$$ select exists (select 1 from public.staff where user_id = auth.uid()) $$;
revoke all on function public.is_staff() from public;
grant execute on function public.is_staff() to anon, authenticated;

-- Clienții (anon) NU au acces direct la bookings/staff. Doar citesc configurația publică.
revoke all on public.bookings, public.staff from anon, authenticated;
grant select on public.bookings to authenticated;           -- filtrat de RLS: doar personal
grant select on public.settings, public.services, public.time_slots to anon, authenticated;
grant insert, update, delete on public.settings, public.services, public.time_slots to authenticated;
grant usage, select on sequence public.time_slots_id_seq to authenticated;

create policy settings_read on public.settings for select using (true);
create policy settings_staff on public.settings for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy services_read on public.services for select using (active or public.is_staff());
create policy services_staff on public.services for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy slots_read on public.time_slots for select using (true);
create policy slots_staff on public.time_slots for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy bookings_staff_read on public.bookings for select to authenticated using (public.is_staff());
-- Fără politici de insert/update/delete pe bookings: toate scrierile trec prin funcțiile de mai jos.

-- ========== Funcții publice (clienți) ==========
create or replace function public.create_booking(p jsonb) returns text
language plpgsql security definer set search_path = public as $$
declare v_svc public.services; v_cap int; v_date date; v_slot text; v_phone text; v_ref text;
begin
  if coalesce(p->>'hp','') <> '' then raise exception 'invalid_request'; end if;  -- honeypot anti-bot
  v_date := (p->>'date')::date; v_slot := p->>'slot'; v_phone := trim(p->>'phone');
  if v_date is null or v_date < (now() at time zone 'Europe/Bucharest')::date then raise exception 'invalid_date'; end if;
  select * into v_svc from public.services where id = p->>'service_id' and active;
  if not found then raise exception 'invalid_service'; end if;
  select capacity into v_cap from public.time_slots where label = v_slot;
  if v_cap is null then raise exception 'invalid_slot'; end if;
  perform pg_advisory_xact_lock(hashtext(v_date::text || '|' || v_slot));
  if (select count(*) from public.bookings where booking_date = v_date and slot_label = v_slot
        and status in ('pending','confirmed')) >= v_cap then raise exception 'slot_taken'; end if;
  if (select count(*) from public.bookings where phone = v_phone and created_at > now() - interval '24 hours') >= 5
    then raise exception 'rate_limit'; end if;
  v_ref := 'MOM-' || upper(encode(gen_random_bytes(4), 'hex'));
  insert into public.bookings (ref, service_id, service_name, cemetery, city, section, plot, row_no, grave_no,
      booking_date, slot_label, customer_name, phone, email, notes)
  values (v_ref, v_svc.id, v_svc.name, trim(p->>'cemetery'), trim(p->>'city'), trim(p->>'section'),
      nullif(trim(p->>'plot'),''), nullif(trim(p->>'row'),''), nullif(trim(p->>'grave'),''),
      v_date, v_slot, trim(p->>'name'), v_phone, lower(trim(p->>'email')), nullif(trim(p->>'notes'),''));
  return v_ref;
end $$;

create or replace function public.get_available_slots(d date) returns table (label text, free boolean)
language sql stable security definer set search_path = public as $$
  select t.label,
    (select count(*) from public.bookings b where b.booking_date = d and b.slot_label = t.label
       and b.status in ('pending','confirmed')) < t.capacity
  from public.time_slots t order by t.sort $$;

-- Statusul se vede doar cu referința ȘI e-mailul folosit la programare
create or replace function public.get_booking_status(p_ref text, p_email text)
returns table (status text, booking_date date, slot_label text)
language sql stable security definer set search_path = public as $$
  select b.status, b.booking_date, b.slot_label from public.bookings b
  where b.ref = upper(trim(p_ref)) and b.email = lower(trim(p_email)) $$;

-- ========== Funcții personal ==========
create or replace function public.staff_list_bookings() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_staff() then raise exception 'forbidden'; end if;
  return (select coalesce(jsonb_agg(jsonb_build_object('id',id,'ref',ref,'name',customer_name,'phone',phone,
    'email',email,'service',service_name,'cemetery',cemetery,'city',city,'section',section,'plot',plot,
    'row',row_no,'grave',grave_no,'date',booking_date,'slot',slot_label,'notes',notes,'status',status,
    'internal',internal_notes,'created',created_at::date) order by booking_date, created_at), '[]'::jsonb)
    from public.bookings);
end $$;

create or replace function public.staff_update_booking(p_id uuid, p_status text default null,
  p_date date default null, p_slot text default null, p_internal text default null) returns void
language plpgsql security definer set search_path = public as $$
declare b public.bookings; n_status text; n_date date; n_slot text; v_cap int;
begin
  if not public.is_staff() then raise exception 'forbidden'; end if;
  select * into b from public.bookings where id = p_id for update;
  if not found then raise exception 'not_found'; end if;
  n_status := coalesce(p_status, b.status); n_date := coalesce(p_date, b.booking_date); n_slot := coalesce(p_slot, b.slot_label);
  if n_status not in ('pending','confirmed','completed','cancelled') then raise exception 'invalid_status'; end if;
  if n_status in ('pending','confirmed')
     and (n_date <> b.booking_date or n_slot <> b.slot_label or b.status in ('completed','cancelled')) then
    select capacity into v_cap from public.time_slots where label = n_slot;
    if v_cap is null then raise exception 'invalid_slot'; end if;
    perform pg_advisory_xact_lock(hashtext(n_date::text || '|' || n_slot));
    if (select count(*) from public.bookings where id <> p_id and booking_date = n_date and slot_label = n_slot
          and status in ('pending','confirmed')) >= v_cap then raise exception 'slot_taken'; end if;
  end if;
  update public.bookings set status = n_status, booking_date = n_date, slot_label = n_slot,
    internal_notes = coalesce(p_internal, internal_notes), updated_at = now() where id = p_id;
end $$;

revoke all on function public.create_booking(jsonb), public.get_available_slots(date),
  public.get_booking_status(text,text), public.staff_list_bookings(),
  public.staff_update_booking(uuid,text,date,text,text) from public;
grant execute on function public.create_booking(jsonb), public.get_available_slots(date),
  public.get_booking_status(text,text) to anon, authenticated;
grant execute on function public.staff_list_bookings(), public.staff_update_booking(uuid,text,date,text,text) to authenticated;

-- După ce creați utilizatorul de personal în Authentication > Users, rulați:
-- insert into public.staff (user_id, email) select id, email from auth.users where email = 'EMAILUL_PERSONALULUI';
